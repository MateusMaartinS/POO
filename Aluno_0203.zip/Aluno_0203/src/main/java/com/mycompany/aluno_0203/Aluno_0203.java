/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.aluno_0203;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Aluno_0203 {

    /**
     * Atividade 03: Nome e Sexo
     * @param args
     */
    public static void main(String[] args) {

        System.out.println("Escreva seu Nome completo");
       
        Scanner palavra = new Scanner(System.in);
        String nome = palavra.nextLine();
        System.out.println("Agora o seu Sexo(use F ou M)");

        char sexo = palavra.next().charAt(0);
        
        switch (sexo) {
            case 'F', 'f' -> System.out.println(nome+"\ndo sexo: Feminino");
            case 'M', 'm' -> System.out.println(nome+"\ndo sexo: Masculino");
            case 'L', 'l' -> System.out.println(nome+"\ndo sexo: Libaneis");
            case 'G', 'g' -> System.out.println(nome+"\ndo sexo: Gremista");            
            default -> System.out.println(nome+"\nProgramador");
        }
            
    }
}
